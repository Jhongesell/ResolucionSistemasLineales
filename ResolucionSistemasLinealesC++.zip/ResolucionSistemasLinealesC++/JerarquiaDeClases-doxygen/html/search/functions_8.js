var searchData=
[
  ['nombre',['nombre',['../classMatriz__Base.html#acf2a367a2fc8151f8d79f18a1e7ea342',1,'Matriz_Base::nombre()'],['../classVector__Base.html#a2a521c86bf6c7a564afa868b8d77533b',1,'Vector_Base::nombre()']]],
  ['normainf',['normaInf',['../classVector.html#a0522989938ab10cd7ba7dc448d4904e2',1,'Vector']]]
];
