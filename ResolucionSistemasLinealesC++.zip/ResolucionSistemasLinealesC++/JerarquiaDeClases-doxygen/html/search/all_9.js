var searchData=
[
  ['jacobi',['JACOBI',['../ResuelveSistemaLineal_8hpp.html#a757914ed6297a006d7fd30933340d009',1,'ResuelveSistemaLineal.hpp']]]
];
