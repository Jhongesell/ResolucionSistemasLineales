var searchData=
[
  ['a',['A',['../classBCGM.html#afa1e495830375b8bde2a973db6bcefba',1,'BCGM']]],
  ['asigna',['asigna',['../classMatriz.html#a2160cd6f675747ebee795a760808b278',1,'Matriz::asigna()'],['../classMatrizBand.html#a3781ba94c201e9ed20d84e84a4ce9473',1,'MatrizBand::asigna()'],['../classMatrizBandComp.html#ad6047aade40b4b36b00f97bd4c5f57a5',1,'MatrizBandComp::asigna()'],['../classMatrizDensa.html#ad51039934b942d2b373843ee54c43c4d',1,'MatrizDensa::asigna()'],['../classMatrizDispersa.html#a926092792cc568d417da810fdd1bcb23',1,'MatrizDispersa::asigna()'],['../classVector.html#a59bec84e428424460ac6a77d41af752a',1,'Vector::asigna()']]],
  ['asignanombre',['asignaNombre',['../classMatriz__Base.html#a659a8b64281fa6f53ae7e3ee8fafa615',1,'Matriz_Base::asignaNombre()'],['../classVector__Base.html#aa2d154b612c6d9450fd0a1c7bb8b8ad4',1,'Vector_Base::asignaNombre()']]]
];
