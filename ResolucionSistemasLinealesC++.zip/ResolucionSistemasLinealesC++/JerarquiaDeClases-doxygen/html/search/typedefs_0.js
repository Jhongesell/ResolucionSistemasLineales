var searchData=
[
  ['ldouble',['ldouble',['../Definiciones_8hpp.html#a8b7a76744fa99ba43b09c8fd0b715cc3',1,'Definiciones.hpp']]]
];
