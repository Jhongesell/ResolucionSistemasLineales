var searchData=
[
  ['liberamatriz',['liberaMatriz',['../classResuelveFactorizacionLUBandDisp.html#a54179c510107dbab10d5a97f96c6eb19',1,'ResuelveFactorizacionLUBandDisp']]]
];
