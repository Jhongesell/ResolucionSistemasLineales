var searchData=
[
  ['depurar',['DEPURAR',['../Definiciones_8hpp.html#a9eeb8ade5c948220247864bf58da2272',1,'Definiciones.hpp']]]
];
