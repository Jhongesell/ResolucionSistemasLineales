var searchData=
[
  ['ldouble',['ldouble',['../Definiciones_8hpp.html#a8b7a76744fa99ba43b09c8fd0b715cc3',1,'Definiciones.hpp']]],
  ['liberamatriz',['liberaMatriz',['../classResuelveFactorizacionLUBandDisp.html#a54179c510107dbab10d5a97f96c6eb19',1,'ResuelveFactorizacionLUBandDisp']]],
  ['liberamemoria',['liberaMemoria',['../classMatriz__Base.html#abd80cfa86b1edba1920b3bea5843fc0b',1,'Matriz_Base::liberaMemoria()'],['../classMatrizBand.html#aa0d7417760979407540adc42ad19b745',1,'MatrizBand::liberaMemoria()'],['../classMatrizBandComp.html#ab6d38d1e80b20939c2233267605e86ec',1,'MatrizBandComp::liberaMemoria()'],['../classMatrizDensa.html#a5feb3cf25a00f8fcf27b07af6ea20ae4',1,'MatrizDensa::liberaMemoria()'],['../classMatrizDispersa.html#aacc0ba3fbb726eb4a232f97ca71189a0',1,'MatrizDispersa::liberaMemoria()'],['../classVector.html#aafcfb743938e04905515b79317a3dc85',1,'Vector::liberaMemoria()']]]
];
