var searchData=
[
  ['matriz_5fbandada',['MATRIZ_BANDADA',['../Matriz__Base_8hpp.html#a4d5b21f7bb01bb9a08c2003fa9fea892',1,'Matriz_Base.hpp']]],
  ['matriz_5fbandada_5fcompacta',['MATRIZ_BANDADA_COMPACTA',['../Matriz__Base_8hpp.html#a53ad2df652209cce1e7f7c93c975c1ac',1,'Matriz_Base.hpp']]],
  ['matriz_5fdensa',['MATRIZ_DENSA',['../Matriz__Base_8hpp.html#a815f336a9ae9481dd4241c461f757dd2',1,'Matriz_Base.hpp']]],
  ['matriz_5fdispersa',['MATRIZ_DISPERSA',['../Matriz__Base_8hpp.html#a13f886a9eeb5d8e0fca1c3985b74c189',1,'Matriz_Base.hpp']]],
  ['matriz_5fdispersa_5fcompacta',['MATRIZ_DISPERSA_COMPACTA',['../Matriz__Base_8hpp.html#aed729c24058f03ac4aae2ba7d31827f7',1,'Matriz_Base.hpp']]],
  ['matriz_5fentera_5fdensa',['MATRIZ_ENTERA_DENSA',['../Matriz__Base_8hpp.html#a0726ae772e79a3cebacff54ace7a9352',1,'Matriz_Base.hpp']]],
  ['matriz_5frala',['MATRIZ_RALA',['../Matriz__Base_8hpp.html#a5f2db2995b8d09d4528fe849c14679ea',1,'Matriz_Base.hpp']]],
  ['matriz_5ftamano_5fvariable',['MATRIZ_TAMANO_VARIABLE',['../Matriz__Base_8hpp.html#a636d912c5cd15be9b8856380e5b36cb2',1,'Matriz_Base.hpp']]]
];
