var searchData=
[
  ['nmb',['Nmb',['../classMatriz__Base.html#a4f0e1223dfc0d838c547d517cc693ef3',1,'Matriz_Base::Nmb()'],['../classVector__Base.html#af5976eb1c3a2c8f5b463f4f16102490f',1,'Vector_Base::Nmb()']]],
  ['numiteraciones',['NumIteraciones',['../classResuelveSistemaLineal.html#a6d29f9283647e58b44a72eb2dd54a1cc',1,'ResuelveSistemaLineal']]]
];
