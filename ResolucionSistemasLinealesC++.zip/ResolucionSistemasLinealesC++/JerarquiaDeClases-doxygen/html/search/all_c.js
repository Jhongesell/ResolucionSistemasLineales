var searchData=
[
  ['nmb',['Nmb',['../classMatriz__Base.html#a4f0e1223dfc0d838c547d517cc693ef3',1,'Matriz_Base::Nmb()'],['../classVector__Base.html#af5976eb1c3a2c8f5b463f4f16102490f',1,'Vector_Base::Nmb()']]],
  ['nombre',['nombre',['../classMatriz__Base.html#acf2a367a2fc8151f8d79f18a1e7ea342',1,'Matriz_Base::nombre()'],['../classVector__Base.html#a2a521c86bf6c7a564afa868b8d77533b',1,'Vector_Base::nombre()']]],
  ['normainf',['normaInf',['../classVector.html#a0522989938ab10cd7ba7dc448d4904e2',1,'Vector']]],
  ['numiteraciones',['NumIteraciones',['../classResuelveSistemaLineal.html#a6d29f9283647e58b44a72eb2dd54a1cc',1,'ResuelveSistemaLineal']]]
];
