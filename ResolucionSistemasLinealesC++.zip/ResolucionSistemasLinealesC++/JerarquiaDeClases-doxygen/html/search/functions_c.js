var searchData=
[
  ['solicitamemoria',['solicitaMemoria',['../classVector.html#a11af55594b8e0e0ddb0d06b358ea12e9',1,'Vector']]],
  ['suma',['suma',['../classMatriz.html#a9d19ded923f861daea1dcdf79012da67',1,'Matriz::suma(Matriz *a, Matriz *b)'],['../classMatriz.html#aada135e9f523ad7056f7588ac802a29c',1,'Matriz::suma(Matriz *a)'],['../classVector.html#ac0572aefdcd58d1b782c8767b0102dab',1,'Vector::suma(Vector *a, Vector *b)'],['../classVector.html#ac45abb9012e157474e345fc7652dd457',1,'Vector::suma(Vector *a)']]]
];
