var searchData=
[
  ['_5f_5fdouble_5f_5f',['__Double__',['../Definiciones_8hpp.html#aae3bbd40bacb947645deb6659f4ebe3c',1,'Definiciones.hpp']]]
];
