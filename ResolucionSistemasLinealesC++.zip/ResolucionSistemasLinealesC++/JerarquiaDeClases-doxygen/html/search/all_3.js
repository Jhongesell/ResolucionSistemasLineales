var searchData=
[
  ['c',['C',['../classResuelveCGM.html#a16f2143be32e4f9d25986d2e3de2b01c',1,'ResuelveCGM']]],
  ['cgm',['CGM',['../ResuelveSistemaLineal_8hpp.html#ac374e41a765a4e6456bd4af07e595b5a',1,'ResuelveSistemaLineal.hpp']]],
  ['col',['Col',['../classMatriz__Base.html#a2ac5307d18ef6cd1df1efa7cd236ceb5',1,'Matriz_Base::Col()'],['../classVector__Base.html#acf0ac045a79e8b3b43545d75aedcdc25',1,'Vector_Base::Col()']]],
  ['columnas',['columnas',['../classMatriz__Base.html#a7407caa46518c4c701160e6b064fa4e7',1,'Matriz_Base::columnas()'],['../classVector__Base.html#aa4b93c305cf6888b4005817604579179',1,'Vector_Base::columnas()']]],
  ['configurametodo',['configuraMetodo',['../classResuelveCGM.html#a134d41bb0275380795fea3f0280f6fd8',1,'ResuelveCGM']]],
  ['convierte',['convierte',['../classMatriz.html#a74023f614956db73f719002e754ba36a',1,'Matriz::convierte(ldouble *a, int ren, int tam)'],['../classMatriz.html#ac8d3f22acf7afd7cbb9c4fd8d3b5a833',1,'Matriz::convierte(ldouble **a, int ren, int col)'],['../classMatriz.html#a031b951137ac7273cfd1a6d652670c6f',1,'Matriz::convierte(int ren, Vector *a)'],['../classMatriz.html#ad88aa93a806bfedd815df674a5f4135b',1,'Matriz::convierte(int ren, int col, ldouble *a)'],['../classVector.html#a5ca3208049c171b3d64817044a0dcc54',1,'Vector::convierte()']]],
  ['copia',['copia',['../classMatriz.html#a03d02833fd66884fad495264948fceb0',1,'Matriz::copia()'],['../classVector.html#a1d0c900d971809efed96f4375b45d1b0',1,'Vector::copia()']]],
  ['ctrl_5fvis_2ehpp',['Ctrl_vis.hpp',['../Ctrl__vis_8hpp.html',1,'']]],
  ['ctrl_5fvisualizacion',['Ctrl_visualizacion',['../classCtrl__visualizacion.html',1,'']]]
];
